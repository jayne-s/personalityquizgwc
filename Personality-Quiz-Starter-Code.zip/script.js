/*Add your JavaScript here*/
var morningPerson = 0;
var nightPerson = 0;
var questionCount=0;
var restartQuiz = document.getElementById("restart");
restartQuiz.addEventListener("click", restartQuiz1);

var selectOption = document.getElementById("q1a1");
var selectOption1 = document.getElementById("q1a2");

var selectOption2 = document.getElementById("q2a1");
var selectOption3 = document.getElementById("q2a2");

var selectOption4 = document.getElementById("q3a1");
var selectOption5 = document.getElementById("q3a2");

var selectOption6 = document.getElementById("q4a1");
var selectOption7 = document.getElementById("q4a2");

selectOption.addEventListener("click", result2);
selectOption1.addEventListener("click", result1);
selectOption2.addEventListener("click", result1);
selectOption3.addEventListener("click", result2);
selectOption4.addEventListener("click", result1);
selectOption5.addEventListener("click", result2);
selectOption6.addEventListener("click", result1);
selectOption7.addEventListener("click", result2);

selectOption.addEventListener("click", disable);
selectOption1.addEventListener("click", disable);
selectOption2.addEventListener("click",disable1);
selectOption3.addEventListener("click", disable1);
selectOption4.addEventListener("click", disable2);
selectOption5.addEventListener("click", disable2);
selectOption6.addEventListener("click", disable3);
selectOption7.addEventListener("click", disable3);

function disable(){
 selectOption.disabled= true;
 selectOption1.disabled= true;
}

function disable1(){
  selectOption2.disabled= true;
  selectOption3.disabled= true;
}

function disable2(){
  selectOption4.disabled= true;
  selectOption5.disabled= true;
}

function disable3(){
  selectOption6.disabled= true;
  selectOption7.disabled= true;
}
/*const button= document.querySelector("q1a1");
if(button ="click"){
  button.disabled= true;
}*/


function result1(){
  morningPerson+=1;
  questionCount+=1;
  console.log("questionCount= " + questionCount + " morningPerson= " + morningPerson);
  if(questionCount==4){
  console.log("The quiz is done!");
 updateResult();
}
}


 function result2(){
  nightPerson+=1;
  questionCount+=1;
  console.log("questionCount= " + questionCount + " nightPerson= " + nightPerson);
    if(questionCount==4){
  console.log("The quiz is done!");
  updateResult();
}
 }

function updateResult(){
if(morningPerson>=3){
  result.innerHTML= "You are a morning person!";
console.log("You are a morning person!");
}
else if(nightPerson>=3){
  result.innerHTML= "You are a night person!";
console.log("You are a night person!");
}
}
function restartQuiz1(){
  result.innerHTML = "You are a...";
  questionCount=0;
  morningPerson=0;
  nightPerson=0;
  selectOption.disabled= false;
 selectOption1.disabled= false;
  selectOption2.disabled= false;
  selectOption3.disabled= false;
  selectOption4.disabled= false;
  selectOption5.disabled= false;
  selectOption6.disabled= false;
  selectOption7.disabled= false;
 }
